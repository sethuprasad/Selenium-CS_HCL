﻿using System;
using TechTalk.SpecFlow;
using SpecFlowIntegration_POM.POM;
using OpenQA.Selenium;

namespace SpecFlowIntegration_POM
{
    [Binding]
    public class FrameWork_SF_POMStepsOne
    {
        MouseActions obj = new MouseActions();
        [Given(@"I have Navigated to '(.*)'")]
        public void GivenIHaveNavigatedTo(string p0)
        {
            //ScenarioContext.Current.Pending();
            obj.Nagvigate(p0);
        }
        
        [When(@"I clicked Draggables")]
        public void WhenIClickedDraggables()
        {
            obj.MoveToElement(1);
          
           // ScenarioContext.Current.Pending();
        }
        
        [When(@"I clicked Droppable")]
        public void WhenIClickedDroppable()
        {
            obj.MoveToElement(2);
            //ScenarioContext.Current.Pending();
        }
        
        [When(@"I Clicked Resizable")]
        public void WhenIClickedResizable()
        {
            obj.MoveToElement(3);
            // ScenarioContext.Current.Pending();
        }
        
        [When(@"I Clicked Selectable")]
        public void WhenIClickedSelectable()
        {
            obj.MoveToElement(4);
            // ScenarioContext.Current.Pending();
        }
        
        [When(@"I Clicked Sortable")]
        public void WhenIClickedSortable()
        {
            obj.MoveToElement(5);
            //ScenarioContext.Current.Pending();
        }
        
        [Then(@"I Performed Drag Operation")]
        public void ThenIPerformedDragOperation()
        {
            obj.DragTheElement();
            //ScenarioContext.Current.Pending();
        }
        
        [Then(@"I performed Drop Operation")]
        public void ThenIPerformedDropOperation()
        {
            //ScenarioContext.Current.Pending();
            obj.DropTheElement();
        }
        
        [Then(@"I done Resize Operation")]
        public void ThenIDoneResizeOperation()
        {
            obj.Resize();
           // ScenarioContext.Current.Pending();
        }
        
        [Then(@"I done Selections")]
        public void ThenIDoneSelections()
        {
            obj.selectables();
           // ScenarioContext.Current.Pending();
        }
        
        [Then(@"I done Sorting")]
        public void ThenIDoneSorting()
        {
            obj.Sortables();
            //ScenarioContext.Current.Pending();
        }
    }
}
