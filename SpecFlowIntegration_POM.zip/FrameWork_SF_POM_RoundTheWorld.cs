﻿using System;
using TechTalk.SpecFlow;
using SpecFlowIntegration_POM.POM;

namespace SpecFlowIntegration_POM
{
    [Binding]
    public class FrameWork_SF_POM_RoundTheWorld
    {
        SpecFlowLocators sfl = new SpecFlowLocators();
        [Given(@"I Navigated to '(.*)'")]
        public void GivenINavigatedTo(string p0)
        {
            string url = sfl.AccessExcelFile("Url");
            sfl.NavigateTo(url);
           // ScenarioContext.Current.Pending();
        }

        [Then(@"I clicked Round TheWorld")]
        public void ThenIClickedRoundTheWorld()
        {
            string locator = sfl.AccessExcelFile("Round_the_world");
            sfl.ByXpath(locator);
            //ScenarioContext.Current.Pending();
        }

        [When(@"I clicked IFLY KLM (.*) screenshort")]
        public void WhenIClickedIFLYKLMScreenshort(int p0)
        {
            string locator = sfl.AccessExcelFile("Round360");
            sfl.ByXpath(locator);
            //ScenarioContext.Current.Pending();
        }

        [Then(@"I Performed (.*)degree action")]
        public void ThenIPerformedDegreeAction(int p0)
        {
            string locator = sfl.AccessExcelFile("arrow");
            sfl.ByCss(locator);
            //ScenarioContext.Current.Pending();
        }

    }
}
