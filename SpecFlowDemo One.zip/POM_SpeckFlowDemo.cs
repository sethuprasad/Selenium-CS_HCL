﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SpecfflowDemoi
{
    [TestClass]
    class POM_SpeckFlowDemo
    {
        //[TestMethod]
        //public void ThaiLand()
        //{
        //    ThailandTaskStepsFinalDemo tl = new ThailandTaskStepsFinalDemo();
        //    tl.GivenIHaveNavigatedToTheTaiLandHomePage("https://www.tourismthailand.org/");
        //    tl.GivenIClickedOnAttractions();
        //    tl.WhenIMovedToSightsAndAttractionsSection();
        //   // tl.ThenISelectedMoresightsAndAttractionsToView();
        //}
    }
}
