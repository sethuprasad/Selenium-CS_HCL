﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using CsvHelper;

namespace Week2_UnitTestProj.StuffPOM
{
    class Reading_From__ExcelFile
    {
        public static IWebDriver driver = null;
        static string output = "";
        [TestMethod]
        public void disp()
        {
            // string str = TestMethod1("browser");
            // Assert.AreEqual("Chrome", str);

            buildElement("Xpath");

        }


        [TestMethod]
        public static IWebElement buildElement(string input)
        {


            IWebElement temp = null;
            switch (ReadFile_iden(input).ToLower())
            {
                case "id":
                    temp = driver.FindElements(By.Id(ReadFile_iden(input)))[3];
                    break;
                case "xpath":
                    temp = driver.FindElements(By.XPath(ReadFile_Value(input)))[3];
                    break;
                default:
                    temp = driver.FindElement(By.ClassName(input));
                    break;
            }
            return temp;
        }

        [TestMethod]
        public static string ReadFile_iden(string input)
        {
            //   IWebDriver driver = new ChromeDriver();
            //driver.Navigate().GoToUrl("http://www.google.com");
            StreamReader dr = File.OpenText(System.IO.Directory.GetCurrentDirectory() + "\\..\\..\\Data\\URL_LOCATORS.csv");
            CsvReader cr = new CsvReader(dr);
            while (cr.Read())
            {
                if (cr.CurrentRecord[2] == input)
                {
                    output = cr.CurrentRecord[2];
                    break;
                }

            }
            return output;

        }

        [TestMethod]
        public static string ReadFile_Value(string input)
        {
            //   IWebDriver driver = new ChromeDriver();
            //driver.Navigate().GoToUrl("http://www.google.com");
            StreamReader dr = File.OpenText(System.IO.Directory.GetCurrentDirectory() + "\\..\\..\\Data\\URL_LOCATORS.csv");
            CsvReader cr = new CsvReader(dr);
            while (cr.Read())
            {
                if (cr.CurrentRecord[2] == input)
                {
                    output = cr.CurrentRecord[3];
                    break;
                }

            }
            return output;

        }
    }
}
