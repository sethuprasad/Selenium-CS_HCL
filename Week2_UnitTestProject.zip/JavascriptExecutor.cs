﻿namespace Week2_UnitTestProj
{
    internal class JavascriptExecutor
    {
    }
}