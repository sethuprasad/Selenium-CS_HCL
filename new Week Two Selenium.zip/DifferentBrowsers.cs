﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;

namespace Week2_UnitTestProj
{
    [TestClass]
    public class DifferentBrowsers
    {
        [TestMethod]
        public void NewWin_Tab()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.google.com");


            IWebDriver driver2 = new InternetExplorerDriver();
            driver2.Navigate().GoToUrl("https://www.google.com");

            IWebDriver driver3 = new FirefoxDriver();
          //  driver3.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10.0);
            driver3.Navigate().GoToUrl("https://www.google.com");



            //Actions new_t = new Actions(driver);
            //List<string> lis = new List<string>();
            //lis.AddRange(driver.WindowHandles);
            //Actions ele = new_t.MoveToElement(driver.FindElement(By.XPath("//*[@id='rso']/div[1]/div/div/div/div[1]/a/h3"))).ContextClick();
            //ele.Build().Perform();

            //driver.SwitchTo().Window(lis[0]);
            //Actions newtab = new Actions(driver);

            //Actions ele1 = new_t.MoveToElement(driver.FindElement(By.XPath("//*[@id='rso']/div[1]/div/div/div/div[1]/a/h3"))).ContextClick().SendKeys(Keys.ArrowDown).SendKeys(Keys.ArrowDown).Release().Click();
            //ele.Build().Perform();

            //newtab.SendKeys(Keys.Control).SendKeys(Keys.Tab).Release().Build().Perform();

            //// Actions newtab = new Actions(driver);
            ////newtab.SendKeys(Keys.ArrowDown).SendKeys(Keys.ArrowDown).Release().Click().Build().Perform();

            //// driver.SwitchTo().DefaultContent();

            //// ele1.SendKeys(Keys.Control).SendKeys(Keys.Tab).Release().Build().Perform();

            //// Actions ele1 = new_t.MoveToElement(driver.FindElement(By.XPath("//*[@id='rso']/div[1]/div/div/div/div[1]/a/h3"))).ContextClick().SendKeys(Keys.ArrowDown).SendKeys(Keys.ArrowDown).Release().Click();
            //// ele.Build().Perform();


        }
    }
}
