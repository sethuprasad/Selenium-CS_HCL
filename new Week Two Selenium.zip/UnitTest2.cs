﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace Week2_UnitTestProj
{
    [TestClass]
    public class UnitTest2
    {
       
      //  [TestMethod]
        //public void TestMethod1()
        //{
        //    DesiredCapabilities capabilities = new DesiredCapabilities();

            
        //    capabilities.SetCapability("browerName", "chrome");
        //    IwebDriver driver = new RemoteWebDriver((new Uri("http://www.google.com")),capabilities);
        //}
    }
}
