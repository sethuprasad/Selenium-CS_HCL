﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Week2_UnitTestProj
{
    [TestClass]
    public class Exception_handeling
    {
        [TestMethod]
        public void HandelinDiffExcep()
        {
            IWebDriver driver = new ChromeDriver();

           // driver.Navigate().GoToUrl("hai.com");

            try
            {
                driver.Navigate().GoToUrl("hai.com");


            }
            catch (WebDriverException we)
            {
                DateTime time = DateTime.Now;
                string dateToday = "_date_" + time.ToString("yyyy-MM-dd") + "_time_" + time.ToString("HH-mm-ss");
                dateToday += "WebDriverException";
                Screenshot screenshot = ((ITakesScreenshot)driver).GetScreenshot();
                screenshot.SaveAsFile((@"D:\ExcImages\Exception"+dateToday+ ".png"));
            }
        }
    }
}
