﻿using System;
using OpenQA.Selenium.Chrome;

namespace Week2_UnitTestProj
{
    internal class IwebDriver
    {
        public static implicit operator IwebDriver(ChromeDriver v)
        {
            throw new NotImplementedException();
        }
    }
}