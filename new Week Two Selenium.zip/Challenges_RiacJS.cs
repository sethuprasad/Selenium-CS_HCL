﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Week2_UnitTestProj
{
    [TestClass]
    public class Challenges_RiacJS
    {
        [TestMethod]
        public void Select_Optiobn()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://paulrajgithub.github.io/GFontsSpace/");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10.0);

            IWebElement ele = driver.FindElement(By.XPath("(//input[contains(@aria-activedescendant,'react-select')])[1]"));
            ele.SendKeys("Alice");

            ele.SendKeys(Keys.Tab);

            IWebElement val = driver.FindElement(By.XPath("(//input[contains(@aria-activedescendant,'react-select')])[2]"));
            string value = val.Text;
           // Assert.AreEqual(value, "Alice");


           //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10.0);
            IWebElement ele1 = driver.FindElement(By.XPath("(//input[contains(@aria-activedescendant,'react-select')])[2]"));
            ele1.SendKeys("regular");

            ele1.SendKeys(Keys.Tab);

            IWebElement font = driver.FindElement(By.XPath("(//input[contains(@type,'number')])"));
           // font.SendKeys(Keys.Backspace);
            font.Clear();
            font.SendKeys("30");

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;

            js.ExecuteScript("document.getElementsByClassName('ColorPicker__Color')[1].style.backgroundColor='Blue';");
            
            //ele.SendKeys(Keys.Enter);





        }
    }
}
