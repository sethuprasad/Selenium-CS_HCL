﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Week2_UnitTestProj
{
    [TestClass]
    public class JavaScriptDemo
    {
        [TestMethod]
        public void TestMethod1()
        {
        IWebDriver driver = new ChromeDriver();
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;

            //Launching the Site.		
            driver.Navigate().GoToUrl("http://demo.guru99.com/V4/");

            //Maximize window		
            driver.Manage().Window.Maximize();

            //Set the Script Timeout to 20 seconds		
            
            driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromSeconds(20.0);

            //Declare and set the start time		
            DateTime start_time = System.DateTime.Now; //System.currentTimeMillis();

            //Call executeAsyncScript() method to wait for 5 seconds	s
            //js.ExecuteAsyncScript();

            //js.executeAsyncScript("window.setTimeout(arguments[arguments.length - 1], 5000);");

            //Get the difference (currentTime - startTime)  of times.		
            //System.out.println("Passed time: " + (System.currentTimeMillis() - start_time));

        }
    }
    }

